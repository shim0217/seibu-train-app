import asyncio
from fastapi import FastAPI, Request
from fastapi.responses import HTMLResponse, JSONResponse  # ← 追加
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
import os
import json
import requests
import httpx
import pytz
from datetime import datetime, timedelta
from contextlib import asynccontextmanager

# 路線定義
lines = {
    "ikebukuro": {"id": "001", "file": "logs/ikebukuro.txt", "name": "西武池袋線"},
    "shinjuku": {"id": "009", "file": "logs/shinjuku.txt", "name": "西武新宿線"},
    "haijima": {"id": "011", "file": "logs/haijima.txt", "name": "西武拝島線"},
}

# Discord設定
DISCORD_TOKEN = "YOUR_DISCORD_BOT_TOKEN"
DISCORD_CHANNEL = "YOUR_CHANNEL_ID"
DISCORD_API = f"https://discord.com/api/v10/channels/{DISCORD_CHANNEL}/messages"
jst = pytz.timezone("Asia/Tokyo")
logs_cache = {}

# JST補正（3時までは前日扱い）
def get_adjusted_jst_now():
    now = datetime.now(jst)
    if now.hour < 3:
        now -= timedelta(days=1)
    return now

# 重複ログチェック（日付＋列車番号）
def is_duplicate_log(new_log, line_key):
    parts = new_log.strip().split(",")
    new_train_no = parts[2]
    new_date = parts[3]

    if line_key in logs_cache:
        existing_logs = logs_cache[line_key]
    else:
        with open(lines[line_key]["file"], "r", encoding="utf-8") as f:
            existing_logs = f.readlines()
        logs_cache[line_key] = existing_logs

    for log in existing_logs:
        log_parts = log.strip().split(",")
        if len(log_parts) < 4:
            continue
        if log_parts[2] == new_train_no and log_parts[3] == new_date:
            return True
    return False

# 非同期列車情報取得
async def fetch_train_data_async(line_key):
    line = lines[line_key]
    sem = asyncio.Semaphore(10)
    seen_train_numbers = set()

    async with httpx.AsyncClient() as client:
        async def fetch(train_no):
            if str(train_no) in seen_train_numbers:
                return
            seen_train_numbers.add(str(train_no))

            url = f"https://train.seibuapp.jp/trainfo-api/ti/v1.0/formations?lineId=L{line['id']}&trainNo={train_no}"
            async with sem:
                try:
                    r = await client.get(url, timeout=5)
                    text = r.text
                    if "不正な値が設定されています" in text:
                        return

                    part1 = text.split('","form')[0]
                    nickname = part1.split('carNickname":"')[-1]
                    part2 = text.split('formationNo":["')[1]
                    formation_raw = part2.split('"]')[0]
                    formation = formation_raw.replace(",", "")
                    adjusted_now = get_adjusted_jst_now()
                    new_log = f"{nickname},{formation},{train_no},{adjusted_now.strftime('%Y-%m-%d')},{get_japanese_weekday_short(adjusted_now)},{adjusted_now.strftime('%H:%M:%S')}"
                    if not is_duplicate_log(new_log, line_key):
                        with open(line["file"], "a", encoding="utf-8") as f:
                            f.write(new_log + "\n")
                        logs_cache[line_key].append(new_log + "\n")
                        send_discord(f"新しい列車データ: {new_log}")
                except Exception as e:
                    print(f"Error fetching train data for {train_no}: {e}")

        tasks = [fetch(train_no) for train_no in range(9700, 10000)]
        await asyncio.gather(*tasks)

# ログディレクトリ確認
def ensure_logs():
    os.makedirs("logs", exist_ok=True)
    for line in lines.values():
        if not os.path.exists(line["file"]):
            open(line["file"], "w").close()

# Discord送信
def send_discord(msg):
    if not DISCORD_TOKEN or not DISCORD_CHANNEL:
        print("Discord設定がありません")
        return
    try:
        response = requests.post(
            DISCORD_API,
            headers={"Authorization": f"Bot {DISCORD_TOKEN}", "Content-Type": "application/json"},
            data=json.dumps({"content": msg})
        )
        print("Discord送信ステータス:", response.status_code)
    except Exception as e:
        print("Discord送信エラー:", e)

# バックグラウンドタスク
async def background_task():
    ensure_logs()
    while True:
        for key in lines:
            await fetch_train_data_async(key)
        await asyncio.sleep(60)

@asynccontextmanager
async def lifespan(app: FastAPI):
    task = asyncio.create_task(background_task())
    yield
    task.cancel()

# FastAPI設定
app = FastAPI(lifespan=lifespan)
app.mount("/static", StaticFiles(directory="static"), name="static")
templates = Jinja2Templates(directory="templates")

# ログキャッシュ取得
def get_logs_from_cache(key):
    if key not in logs_cache:
        with open(lines[key]["file"], "r", encoding="utf-8") as f:
            logs_cache[key] = f.readlines()
    return logs_cache[key]

# HTML表示
@app.get("/", response_class=HTMLResponse)
async def get_logs(request: Request, q: str = ""):
    query = q.strip()
    filtered_logs = []
    logs_data = {}
    for key, line in lines.items():
        logs = get_logs_from_cache(key)
        logs.reverse()
        log_list = []
        for log in logs:
            parts = log.strip().split(",")
            if len(parts) < 6:
                continue
            entry = {
                "alias": parts[0],
                "formation": parts[1],
                "number": parts[2],
                "date": parts[3],
                "day": parts[4],
                "time": parts[5],
                "icon": get_icon_by_formation(parts[1]),
                "type": get_train_type(parts[2]),
                "line": line["name"],
                "cars": len(parts[1].split(","))
            }
            if query and query in log:
                filtered_logs.append(entry)
            log_list.append(entry)
        logs_data[key] = log_list

    return templates.TemplateResponse("index.html", {
        "request": request,
        "lines": lines,
        "logs": logs_data,
        "query": query,
        "filtered_logs": filtered_logs
    })

# 編成番号からアイコン取得
def get_icon_by_formation(formation):
    f = formation.replace("F", "").lower()
    try:
        f_number = int(f)
        if 2001 <= f_number <= 2999:
            return "2000kei.png"
        elif 4000 <= f_number <= 4999:
            return "4000kei.png"
        elif 6000 <= f_number <= 6999:
            return "6000kei.png"
        elif 10000 <= f_number <= 10199:
            return "10000kei.png"
        elif 20000 <= f_number <= 20199:
            return "20000kei.png"
        elif 30000 <= f_number <= 39199:
            return "30000kei.png"
        elif 40000 <= f_number <= 49199:
            return "40000.png"
    except ValueError:
        pass

    if "laview" in f:
        return "laview.png"
    if f in ["1247", "1253", "1259"]:
        return "akaden.png"
    elif f in ["1245", "1249"]:
        return "twotone.png"
    elif f == "1241":
        return "izu.png"
    elif f == "1251":
        return "omi.png"
    elif f.startswith("124"):
        return "101kei.png"
    elif f == "4009":
        return "52seki.png"
    elif f.startswith("40"):
        return "4000kei.png"
    elif f.startswith("n2000"):
        return "n2000.png"
    elif f.startswith("2000"):
        return "2000kei.png"
    elif f.startswith("6000"):
        return "6000kei.png"
    elif f.startswith("20000"):
        return "20000kei.png"
    elif f.startswith("30000"):
        return "30000kei.png"
    elif f.startswith("40000"):
        return "40000.png"
    elif f == "001":
        return "001kei.png"
    elif f == "10000":
        return "10000kei.png"

    return "default.png"

# 種別判定
def get_train_type(number):
    try:
        n = int(number)
        if 9700 <= n <= 9799:
            return "不定期試運転"
        elif 9800 <= n <= 9899:
            return "不定期回送"
        elif 9900 <= n <= 9969:
            return "臨時回送"
        elif 9970 <= n <= 9999:
            return "臨時試運転"
    except:
        pass
    return "通常"

# 曜日を日本語の略称に
def get_japanese_weekday_short(dt):
    weekdays = ["月", "火", "水", "木", "金", "土", "日"]
    return weekdays[dt.weekday()]

# 🔽🔽🔽🔽 追加: 最終更新時刻取得用のAPIエンドポイント
@app.get("/log_timestamp")
async def log_timestamp():
    latest_update = max(
        os.path.getmtime(line["file"]) for line in lines.values() if os.path.exists(line["file"])
    )
    return JSONResponse({"timestamp": latest_update})
# 🔼🔼🔼🔼
